package com.Application;

import java.util.Scanner;

import com.Entity.Bank;

public class App {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		Bank b = new Bank();
		boolean start = true;
		while(start) {

			System.out.println("\n ~: SELECT ONE OF THE BELOW :~");
			System.out.println("\t 1] Adding New Customer");
			System.out.println("\t 2] Updating Customers Details");
			System.out.println("\t 3] Deleting Customer");
			System.out.println("\t 4] Getting Data of All Customers");
			System.out.println("\t 5] Get Detail of Particular Customer");
			System.out.println("\t 6] Withdraw Amount");
			System.out.println("\t 7] Deposite Amount");
			System.out.println("\t 8] Exit");
			
			int ch = sc.nextInt();
			
			switch(ch) {
			
			case 1 : b.insert();
				break;
				
			case 2 : b.update();
				break;
				
			case 3 : b.delete();
				break;
				
			case 4 : b.getAllData();
				break;
				
			case 5 : b.getSingleData();
				break;
				
			case 6 : b.withdraw();
				break;
				
			case 7 : b.deposite();
				break;
				
			case 8 : start = false;
				System.out.println(" ~: THANK YOU :~");
				break;
			}
		}
	}

}
