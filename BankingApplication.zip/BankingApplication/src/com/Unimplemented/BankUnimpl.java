package com.Unimplemented;

public interface BankUnimpl {

	public abstract void insert();
	
	public abstract void update();
	
	public abstract void delete();
	
	public abstract void getAllData();
	
	public abstract void getSingleData();
	
	public abstract void withdraw();
	
	public abstract void deposite();
}
