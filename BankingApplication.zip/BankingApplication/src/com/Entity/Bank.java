package com.Entity;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

import com.Configuration.Config;
import com.Unimplemented.BankUnimpl;

public class Bank implements BankUnimpl{

	Scanner sc = new Scanner(System.in);
	
	@Override
	public void insert() {
		try {
			Connection con = Config.connectToDB();
			PreparedStatement ps = con.prepareStatement("insert into customer values(?, ?, ?, ?);");
			
			System.out.println("How many customer you want to Add ?");
			int no = sc.nextInt();
			
			for(int i = 1 ; i <= no ; i++) {
				System.out.println("Enter the details for " + i + " customer ->");
				System.out.println("Enter Id : ");
				int id = sc.nextInt();
				
				System.out.println("Enter UserName : ");
				String name = sc.next();
				
				System.out.println("Enter Balance : ");
				double balance = sc.nextDouble();
				
				System.out.println("Enter Account number : ");
				long ac = sc.nextLong();
				
				ps.setInt(1, id);
				ps.setString(2, name);
				ps.setDouble(3, balance);
				ps.setLong(4, ac);
				
				int row = ps.executeUpdate();
				if(row > 0) {
					System.out.println("Record insert succesfully ! !");
				}else {
					System.out.println("Error ! ");
				}
			}
			ps.close();
			con.close();
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Override
	public void update() {
		try {
			Connection con = Config.connectToDB();
			
			System.out.println("Enter the id where you want to update : ");
			int newId = sc.nextInt();
			
			boolean start = true;
			while(start) {
			
				System.out.println("What you want to update ?");
				System.out.println("\t 1] Name of customer");
				System.out.println("\t 2] Balance of customer");
				System.out.println("\t 3] Account Number of customer");
				System.out.println("\t 4] Exit");
				
				System.out.println("Enter your choice : ");
				int ch = sc.nextInt();
				
				switch(ch) {
				case 1:
					PreparedStatement ps1 = con.prepareStatement("update customer set name = ? where id = ? ;");
					System.out.println("Enter name to update: ");
					String newName = sc.next();
					ps1.setString(1, newName);
					ps1.setInt(2, newId);
					int row1 = ps1.executeUpdate();
					if(row1 > 0) {
						System.out.println("Name updated succesfully ! !");
					}else {
						System.out.println("Error ! ");
					}
					ps1.close();
					break;
				case 2:
					PreparedStatement ps2 = con.prepareStatement("update customer set balance = ? where id = ? ;");
					System.out.println("Enter balance to update: ");
					String newBalance = sc.next();
					ps2.setString(1, newBalance);
					ps2.setInt(2, newId);
					int row2 = ps2.executeUpdate();
					if(row2 > 0) {
						System.out.println("Balance updated succesfully ! !");
					}else {
						System.out.println("Error ! ");
					}
					ps2.close();
					break;
				case 3:
					PreparedStatement ps3 = con.prepareStatement("update customer set account_no = ? where id = ? ;");
					System.out.println("Enter name to update: ");
					String newAccount_no = sc.next();
					ps3.setString(1, newAccount_no);
					ps3.setInt(2, newId);
					int row3 = ps3.executeUpdate();
					if(row3 > 0) {
						System.out.println("Account number updated succesfully ! !");
					}else {
						System.out.println("Error ! ");
					}
					ps3.close();
					break;
					
				case 4 :start = false;
					break;
				  
				}
			}
			con.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}

	@Override
	public void delete() {
		try {
			Connection con = Config.connectToDB();
			PreparedStatement ps = con.prepareStatement("delete from customer where id = ? ;");
			
			System.out.println("Enter id where you want to delete:");
			int newId = sc.nextInt();
			
			ps.setInt(1, newId);
			
			int row = ps.executeUpdate();
			if(row > 0) {
				System.out.println("Record deleted succesfully ! !");
			}else {
				System.out.println("Error ! ");
			}
			ps.close();
			con.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}

	@Override
	public void getAllData() {
		try {
			Connection con = Config.connectToDB();
			Statement st = con.createStatement();
			ResultSet set = st.executeQuery("Select * from customer;");
			
			while(set.next()) {
				int id = set.getInt(1);
				String name = set.getString(2);
				double balance = set.getDouble(3);
				long account_no = set.getLong(4);
				
				System.out.println("\n ID : "+ id +" \t Name : "+ name +" \t Balance : "+ balance +" \t Account No. : "+ account_no);
			}
			st.close();
			con.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}

	@Override
	public void getSingleData() {
		try {
			Connection con = Config.connectToDB();
			PreparedStatement ps = con.prepareStatement("select * from customer where id = ? ;");
			System.out.println("Enter the id to show details : ");
			int newId = sc.nextInt();
			
			ps.setInt(1, newId);
			ResultSet set = ps.executeQuery();
			while(set.next()) {
				int id = set.getInt(1);
				String name = set.getString(2);
				double balance = set.getDouble(3);
				long account_no = set.getLong(4);
				
				System.out.println("\n ID : "+ id +" \t Name : "+ name +" \t Balance : "+ balance +" \t Account No. : "+ account_no);
			}
			ps.close();
			con.close();
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}

	@Override
	public void withdraw() {
		System.out.println("Enter Id : ");
		int newId = sc.nextInt();
		
		System.out.println("Enter Amount : ");
		double amt = sc.nextDouble();
		
		try {
			Connection con = Config.connectToDB();
			PreparedStatement ps = con.prepareStatement("select * from customer where id = ? ;");
			
			ps.setInt(1, newId);
			ResultSet set = ps.executeQuery();
			double b = 0;
			while(set.next()) {
				b = set.getDouble(3);
			}
			b = b - amt;
			System.out.println(b);
			
			PreparedStatement ps1 = con.prepareStatement("update customer set balance = ? where id = ? ;");
			ps1.setDouble(1, b);
			ps1.setInt(2, newId);
			int row = ps1.executeUpdate();
			if(row > 0) {
				System.out.println("Balance updated succesfully ! !");
				
			}else {
				System.out.println("Error ! ");
			}
			ps1.close();
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}

	@Override
	public void deposite() {
		System.out.println("Enter Id : ");
		int newId = sc.nextInt();
		
		System.out.println("Enter Amount : ");
		double amt = sc.nextDouble();
		
		try {
			Connection con = Config.connectToDB();
			PreparedStatement ps = con.prepareStatement("select * from customer where id = ? ;");
			
			ps.setInt(1, newId);
			ResultSet set = ps.executeQuery();
			double b = 0;
			while(set.next()) {
				b = set.getDouble(3);
			}
			b = b + amt;
			System.out.println(b);
			
			PreparedStatement ps1 = con.prepareStatement("update customer set balance = ? where id = ? ;");
			ps1.setDouble(1, b);
			ps1.setInt(2, newId);
			int row = ps1.executeUpdate();
			if(row > 0) {
				System.out.println("Balance updated succesfully ! !");
				
			}else {
				System.out.println("Error ! ");
			}
			ps1.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
}